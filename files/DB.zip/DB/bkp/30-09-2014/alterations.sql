---24/09/2014-------
ALTER TABLE `organisations` ADD `fa_account` TINYINT NOT NULL DEFAULT '0' COMMENT '1 for fa_account created else 0';
