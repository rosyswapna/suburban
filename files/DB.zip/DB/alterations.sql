--------------------10/10/2014---------------swapna

ALTER TABLE `users` ADD `fa_account` INT( 11 ) NOT NULL DEFAULT '0' COMMENT 'fa user id'

